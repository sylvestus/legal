<?php

// This is a LCM language file  --  Ceci est un fichier langue de LCM

include_lcm('lang/lcm_en');

$local_strings = array(

'0_language' => 'English (UK) [en_uk]',
'currency_default_format' => '£'

);

$GLOBALS[$GLOBALS['idx_lang']] = array_merge($GLOBALS[$GLOBALS['idx_lang']], $local_strings);

?>
