This directory must give write access to the webserver.
Either chmod 777 or chown to apache/httpd.
