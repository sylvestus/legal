<?php
$GLOBALS['author_session']['id_author'] = '4';
$GLOBALS['author_session']['name_first'] = 'Annah ';
$GLOBALS['author_session']['name_middle'] = '';
$GLOBALS['author_session']['name_last'] = 'Gitonga';
$GLOBALS['author_session']['username'] = 'annegatwiri';
$GLOBALS['author_session']['email'] = '';
$GLOBALS['author_session']['status'] = 'normal';
$GLOBALS['author_session']['lang'] = 'en';
$GLOBALS['author_session']['ip_change'] = '';
$GLOBALS['author_session']['hash_env'] = 'd41d8cd98f00b204e9800998ecf8427e';
?>
