<?php
$GLOBALS['author_session']['id_author'] = '1';
$GLOBALS['author_session']['name_first'] = 'Sebastian';
$GLOBALS['author_session']['name_middle'] = '';
$GLOBALS['author_session']['name_last'] = 'Muema';
$GLOBALS['author_session']['username'] = 'administrator';
$GLOBALS['author_session']['email'] = '';
$GLOBALS['author_session']['status'] = 'admin';
$GLOBALS['author_session']['lang'] = 'en_uk';
$GLOBALS['author_session']['ip_change'] = '';
$GLOBALS['author_session']['hash_env'] = 'd41d8cd98f00b204e9800998ecf8427e';
?>
