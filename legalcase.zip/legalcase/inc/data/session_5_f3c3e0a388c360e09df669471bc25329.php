<?php
$GLOBALS['author_session']['id_author'] = '5';
$GLOBALS['author_session']['name_first'] = 'Benjamin';
$GLOBALS['author_session']['name_middle'] = '';
$GLOBALS['author_session']['name_last'] = 'Kawamara';
$GLOBALS['author_session']['username'] = 'kawamara';
$GLOBALS['author_session']['email'] = '';
$GLOBALS['author_session']['status'] = 'admin';
$GLOBALS['author_session']['lang'] = 'en';
$GLOBALS['author_session']['ip_change'] = '';
$GLOBALS['author_session']['hash_env'] = 'd41d8cd98f00b204e9800998ecf8427e';
?>
